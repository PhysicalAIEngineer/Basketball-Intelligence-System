# Basketball Intelligence System — Evaluation Module

This folder adds a quantitative evaluation layer to the existing Basketball Intelligence System.

## What the upstream project already contains

The existing pipeline performs player tracking, ball tracking, court keypoint detection, team assignment, ball possession, pass/interception detection, tactical-view transformation, and speed/distance calculation. It also validates frame counts between stages. The upstream code does **not** currently calculate the requested benchmark metrics against ground truth: mAP, IDF1/HOTA, team accuracy, court MAE, speed MAE, possession F1, or event precision/recall/F1.

## Added metrics

| Component | Metrics |
|---|---|
| Player detection | mAP@50, mAP@50:95 |
| Ball detection | mAP@50, mAP@50:95 |
| Tracking | IDF1; HOTA through TrackEval |
| Team classification | Accuracy, macro F1 |
| Court mapping | Euclidean position MAE/RMSE, X/Y MAE |
| Speed | MAE/RMSE |
| Possession | Precision, Recall, F1 |
| Pass detection | Precision, Recall, F1 |
| Interception | Precision, Recall, F1 |

## Important

A valid evaluation requires **independent ground truth annotations**. Do not copy predictions into the ground-truth file. The numbers in the resume target table are project goals, not measured results.

## Folder structure

```text
Basketball-Intelligence-System/
├── evaluation/
│   ├── __init__.py
│   ├── metrics.py
│   ├── evaluate_project.py
│   ├── prediction_exporter.py
│   ├── export_mot.py
│   ├── trackeval_adapter.py
│   ├── main_integration_snippet.py
│   ├── requirements-evaluation.txt
│   └── patches/
│       ├── player_tracker_with_confidence.py
│       └── ball_tracker_with_confidence.py
├── data/
│   ├── ground_truth/
│   │   └── ground_truth.json
│   └── predictions/
│       └── predictions.json
└── reports/
    └── metrics.json
```

## Install

From repository root:

```bash
pip install -r requirements.txt
pip install -r evaluation/requirements-evaluation.txt
```

For official HOTA/IDF1 evaluation:

```bash
git clone https://github.com/JonathonLuiten/TrackEval.git
pip install -e TrackEval
```

## Prediction / ground-truth JSON

Each frame can contain players, ball, possession, court coordinates and speed:

```json
{
  "event_tolerance_frames": 3,
  "frames": {
    "1": {
      "players": [
        {
          "track_id": 7,
          "bbox": [500, 200, 560, 380],
          "class_id": 0,
          "team_id": 1,
          "court_xy": [13.4, 7.8],
          "speed_kmh": 15.2
        }
      ],
      "ball": [
        {
          "bbox": [570, 270, 583, 283],
          "confidence": 0.92,
          "class_id": 0
        }
      ],
      "possession_team": 1
    }
  },
  "events": [
    {"type": "pass", "frame": 120, "team": 1},
    {"type": "interception", "frame": 180, "team": 2}
  ]
}
```

Use the same schema for `ground_truth.json` and `predictions.json`.

## Export predictions from the existing pipeline

After the existing `main.py` has generated:

```text
player_tracks
ball_tracks
player_assignment
ball_aquisition
passes
interceptions
tactical_player_positions
player_speed_per_frame
```

add the code in:

```text
evaluation/main_integration_snippet.py
```

This writes:

```text
data/predictions/predictions.json
```

The upstream player/ball trackers currently save bounding boxes but discard detector confidence. That is enough for tracking, but confidence is needed for meaningful AP/mAP. Use the confidence-aware tracker patches in:

```text
evaluation/patches/
```

and regenerate the tracking stubs.

## Run complete evaluation

```bash
python evaluation/evaluate_project.py   --gt data/ground_truth/ground_truth.json   --pred data/predictions/predictions.json   --report reports/metrics.json
```

The report contains:

```text
Player mAP50 / mAP50-95
Ball mAP50 / mAP50-95
Tracking IDF1
Team accuracy / macro F1
Court position MAE / RMSE
Speed MAE / RMSE
Possession precision / recall / F1
Pass precision / recall / F1
Interception precision / recall / F1
```

## Detection mAP

The implementation performs class-aware IoU matching. At IoU >= 0.50 a prediction can be a true positive; unmatched predictions are false positives and unmatched ground-truth objects are false negatives.

It reports:

```text
mAP50
mAP50_95
AP at IoU 0.50 ... 0.95
```

## Tracking IDF1

Tracking input uses:

```text
frame
track_id
bbox
```

The evaluator performs IoU matching per frame and global GT-ID/predicted-ID assignment.

For publication-grade HOTA/IDF1, use TrackEval rather than an approximate implementation.

## HOTA

Convert prediction and ground truth to MOT format:

```bash
python evaluation/export_mot.py   --input data/predictions/predictions.json   --output data/predictions/mot_pred.txt

python evaluation/export_mot.py   --input data/ground_truth/ground_truth.json   --output data/ground_truth/mot_gt.txt
```

Then adapt those files to the TrackEval custom/MOT benchmark directory structure and run the official TrackEval scripts.

TrackEval provides HOTA, DetA, AssA, LocA, DetPr, DetRe, AssPr, AssRe and IDF1.

## Team classification

For matched player IDs:

```text
GT team_id == predicted team_id
```

is correct. The evaluator reports accuracy and macro F1.

## Court mapping MAE

Each matched player needs:

```text
court_xy = [x_meters, y_meters]
```

The evaluator computes Euclidean error:

```text
sqrt((x_gt-x_pred)^2 + (y_gt-y_pred)^2)
```

and reports mean error in meters plus X/Y MAE.

## Speed MAE

For matched player/frame samples:

```text
MAE = mean(abs(speed_gt - speed_pred))
```

The project uses km/h for speed.

## Possession F1

Frame-level labels:

```text
0 = unknown
1 = Team 1
2 = Team 2
```

Unknown is ignored by default for the main possession F1.

## Pass/interception metrics

Events are matched one-to-one by event type and temporal proximity. The default tolerance is ±3 frames.

Each event evaluator reports:

```text
TP
FP
FN
Precision
Recall
F1
```

For a 30 FPS video, ±3 frames corresponds to about ±100 ms.

## Recommended ground-truth annotation

For a serious benchmark, annotate:

```text
Player bbox
Player track ID
Ball bbox
Team ID
Court position
Player speed
Possession team/player
Pass frame
Pass team
Interception frame
Interception team
```

Use a held-out test set for final reporting.

## Correct evaluation workflow

```text
Basketball Video
      |
      v
Existing CV Pipeline
      |
      v
predictions.json
      |
      | compare
      v
independent ground_truth.json
      |
      v
Evaluation Module
      |
      +--> Detection: mAP
      +--> Tracking: IDF1/HOTA
      +--> Team: Accuracy/F1
      +--> Court: MAE
      +--> Speed: MAE
      +--> Possession: F1
      +--> Pass: P/R/F1
      +--> Interception: P/R/F1
      |
      v
reports/metrics.json
```

## Do not claim target numbers without measurement

For example, this is a target:

```text
Player mAP50 >= 95%
IDF1 >= 85%
HOTA >= 75%
Team Accuracy >= 95%
Court MAE < 1 m
Speed MAE < 1-2 km/h
Possession F1 >= 90%
```

It becomes a resume result only after running the evaluator on a held-out, manually annotated dataset and obtaining the corresponding measured values.
