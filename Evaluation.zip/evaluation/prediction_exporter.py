"""
Export the in-memory outputs of the existing Basketball Intelligence System
into the evaluation JSON schema.

Call this AFTER:
    player_tracks
    ball_tracks
    player_assignment
    ball_aquisition
    passes
    interceptions
    tactical_player_positions
    player_speed_per_frame

Example in main.py:

from evaluation.prediction_exporter import save_predictions

save_predictions(
    output_path=BASE_DIR / "data" / "predictions" / "predictions.json",
    player_tracks=player_tracks,
    ball_tracks=ball_tracks,
    player_assignment=player_assignment,
    ball_aquisition=ball_aquisition,
    passes=passes,
    interceptions=interceptions,
    tactical_player_positions=tactical_player_positions,
    player_speed_per_frame=player_speed_per_frame,
)
"""
from pathlib import Path
import json
import math


def _safe_int(x):
    try:
        return int(x)
    except Exception:
        return None


def _safe_float(x, default=None):
    try:
        x=float(x)
        return x if math.isfinite(x) else default
    except Exception:
        return default


def _get_frame_value(seq, frame, player_id, default=None):
    if seq is None or frame >= len(seq):
        return default
    obj=seq[frame]
    if not isinstance(obj, dict):
        return default
    # Handle integer/string keys.
    if player_id in obj:
        return obj[player_id]
    if str(player_id) in obj:
        return obj[str(player_id)]
    return default


def _normalise_events(passes, interceptions):
    events=[]
    for e in passes or []:
        if not isinstance(e,dict) or e.get("frame") is None:
            continue
        item=dict(e)
        item["type"]="pass"
        item["frame"]=_safe_int(item["frame"])
        events.append(item)

    for e in interceptions or []:
        if not isinstance(e,dict) or e.get("frame") is None:
            continue
        item=dict(e)
        item["type"]="interception"
        item["frame"]=_safe_int(item["frame"])
        events.append(item)

    return sorted([e for e in events if e["frame"] is not None],
                  key=lambda x:x["frame"])


def _team_possession(possession_player, player_assignment, frame):
    if possession_player is None:
        return 0
    try:
        pid=int(possession_player)
    except Exception:
        return 0
    if pid < 0:
        return 0
    assignment=_get_frame_value(player_assignment, frame, pid, None)
    if assignment in (1,2):
        return int(assignment)
    return 0


def save_predictions(output_path, player_tracks, ball_tracks,
                     player_assignment=None, ball_aquisition=None,
                     passes=None, interceptions=None,
                     tactical_player_positions=None,
                     player_speed_per_frame=None):

    if player_tracks is None:
        raise ValueError("player_tracks is required")
    n=len(player_tracks)

    frames={}

    for frame_idx in range(n):
        frame_out={"players":[],"ball":[],"possession_team":0}

        players=player_tracks[frame_idx] or {}
        for pid, info in players.items():
            if not isinstance(info,dict) or "bbox" not in info:
                continue

            item={
                "track_id":_safe_int(pid),
                "bbox":[float(v) for v in info["bbox"]]
            }

            # Current upstream PlayerTracker does not preserve confidence.
            # If your tracker has been patched to save it, this is exported.
            conf=info.get("confidence")
            if conf is not None:
                item["confidence"]=float(conf)

            cls=info.get("class_id",0)
            if cls is not None:
                item["class_id"]=_safe_int(cls) or 0

            team=_get_frame_value(player_assignment,frame_idx,pid,None)
            if team in (1,2):
                item["team_id"]=int(team)

            xy=_get_frame_value(tactical_player_positions,frame_idx,pid,None)
            if xy is not None:
                try:
                    item["court_xy"]=[float(xy[0]),float(xy[1])]
                except Exception:
                    pass

            speed=_get_frame_value(player_speed_per_frame,frame_idx,pid,None)
            speed=_safe_float(speed)
            if speed is not None:
                item["speed_kmh"]=speed

            frame_out["players"].append(item)

        # BallTracker stores the primary ball as track ID 1.
        balls=ball_tracks[frame_idx] if ball_tracks is not None and frame_idx < len(ball_tracks) else {}
        for bid, info in (balls or {}).items():
            if not isinstance(info,dict) or "bbox" not in info:
                continue
            item={
                "track_id":_safe_int(bid),
                "bbox":[float(v) for v in info["bbox"]],
                "class_id":0
            }
            conf=info.get("confidence")
            item["confidence"]=float(conf) if conf is not None else 1.0
            frame_out["ball"].append(item)

        possession_player=ball_aquisition[frame_idx] if ball_aquisition is not None and frame_idx < len(ball_aquisition) else -1
        frame_out["possession_player"]=_safe_int(possession_player)
        frame_out["possession_team"]=_team_possession(possession_player,player_assignment,frame_idx)

        frames[str(frame_idx)] = frame_out

    output={
        "event_tolerance_frames":3,
        "frames":frames,
        "events":_normalise_events(passes,interceptions)
    }

    output_path=Path(output_path)
    output_path.parent.mkdir(parents=True,exist_ok=True)
    with open(output_path,"w",encoding="utf-8") as f:
        json.dump(output,f,indent=2)

    print(f"Saved predictions: {output_path}")
    return output
