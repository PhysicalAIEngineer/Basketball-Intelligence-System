"""
Optional HOTA/IDF1 adapter using the official TrackEval implementation.

Input:
  data/ground_truth/mot_gt.txt
  data/predictions/mot_pred.txt

MOT format:
frame,id,x,y,width,height,conf,class,visibility
"""
from pathlib import Path
import subprocess, sys


def run_trackeval(trackeval_root, gt_root, tracker_root, tracker_name="basketball",
                  seqmap="seqmap.txt"):
    trackeval_root=Path(trackeval_root).resolve()
    gt_root=Path(gt_root).resolve()
    tracker_root=Path(tracker_root).resolve()

    cmd=[
        sys.executable,
        str(trackeval_root/"scripts"/"run_mot_challenge.py"),
        "--GT_FOLDER", str(gt_root),
        "--TRACKERS_FOLDER", str(tracker_root),
        "--TRACKERS_TO_EVAL", tracker_name,
        "--BENCHMARK", "MOT17",
        "--SPLIT_TO_EVAL", "train",
        "--METRICS", "HOTA", "CLEAR", "Identity",
        "--USE_PARALLEL", "False",
        "--NUM_PARALLEL_CORES", "1",
        "--DO_PREPROC", "False",
    ]
    return subprocess.run(cmd, check=True, text=True, capture_output=True)


if __name__ == "__main__":
    print("Use run_trackeval(...) from evaluate_project.py after installing TrackEval.")
