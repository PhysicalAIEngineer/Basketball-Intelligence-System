"""
Basketball Intelligence System - evaluation metrics.

This module evaluates predictions against manually annotated ground truth.
It does NOT manufacture scores from predictions alone.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, List, Any, Tuple, Optional
import math
import numpy as np
from scipy.optimize import linear_sum_assignment


def bbox_iou(a, b) -> float:
    ax1, ay1, ax2, ay2 = map(float, a)
    bx1, by1, bx2, by2 = map(float, b)
    ix1, iy1 = max(ax1, bx1), max(ay1, by1)
    ix2, iy2 = min(ax2, bx2), min(ay2, by2)
    iw, ih = max(0.0, ix2-ix1), max(0.0, iy2-iy1)
    inter = iw * ih
    area_a = max(0.0, ax2-ax1) * max(0.0, ay2-ay1)
    area_b = max(0.0, bx2-bx1) * max(0.0, by2-by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def _ap_from_pr(recall: np.ndarray, precision: np.ndarray) -> float:
    if recall.size == 0:
        return 0.0
    mrec = np.concatenate(([0.0], recall, [1.0]))
    mpre = np.concatenate(([0.0], precision, [0.0]))
    for i in range(len(mpre)-2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i+1])
    idx = np.where(mrec[1:] != mrec[:-1])[0]
    return float(np.sum((mrec[idx+1]-mrec[idx]) * mpre[idx+1]))


def detection_ap(gt_frames: Dict[str, Any], pred_frames: Dict[str, Any],
                 object_key: str = "players", iou_threshold: float = 0.5,
                 class_id: Optional[int] = None) -> float:
    """
    COCO/YOLO-style class-aware AP for one object type at one IoU threshold.
    Ground truth items need bbox and optional class_id.
    Prediction items need bbox and confidence and optional class_id.
    """
    gt_by_frame = {}
    total_gt = 0
    for f, data in gt_frames.items():
        items = data.get(object_key, []) or []
        if class_id is not None:
            items = [x for x in items if x.get("class_id", 0) == class_id]
        gt_by_frame[str(f)] = items
        total_gt += len(items)

    predictions = []
    for f, data in pred_frames.items():
        items = data.get(object_key, []) or []
        if class_id is not None:
            items = [x for x in items if x.get("class_id", 0) == class_id]
        for p in items:
            predictions.append((float(p.get("confidence", 1.0)), str(f), p))
    predictions.sort(key=lambda x: x[0], reverse=True)

    if total_gt == 0:
        return float("nan")

    matched = {str(f): np.zeros(len(items), dtype=bool)
               for f, items in gt_by_frame.items()}
    tp, fp = [], []

    for conf, f, p in predictions:
        gts = gt_by_frame.get(f, [])
        best_iou, best_j = 0.0, -1
        for j, g in enumerate(gts):
            if matched[f][j]:
                continue
            iou = bbox_iou(p["bbox"], g["bbox"])
            if iou > best_iou:
                best_iou, best_j = iou, j
        if best_iou >= iou_threshold:
            matched[f][best_j] = True
            tp.append(1); fp.append(0)
        else:
            tp.append(0); fp.append(1)

    if not tp:
        return 0.0
    tp = np.cumsum(np.asarray(tp))
    fp = np.cumsum(np.asarray(fp))
    recall = tp / max(total_gt, 1)
    precision = tp / np.maximum(tp + fp, 1)
    return _ap_from_pr(recall, precision)


def evaluate_detection(gt_frames, pred_frames, object_key="players",
                       class_id=None):
    thresholds = np.arange(0.50, 0.96, 0.05)
    values = [detection_ap(gt_frames, pred_frames, object_key, float(t), class_id)
              for t in thresholds]
    return {
        "mAP50": float(values[0]),
        "mAP50_95": float(np.nanmean(values)),
        "AP_by_IoU": {f"{t:.2f}": float(v) for t, v in zip(thresholds, values)}
    }


def classification_metrics(y_true, y_pred, labels=(0, 1, 2)):
    yt, yp = list(y_true), list(y_pred)
    if len(yt) != len(yp):
        raise ValueError("Classification arrays must have equal length.")
    per_class = {}
    for c in labels:
        tp = sum(a == c and b == c for a,b in zip(yt,yp))
        fp = sum(a != c and b == c for a,b in zip(yt,yp))
        fn = sum(a == c and b != c for a,b in zip(yt,yp))
        p = tp/(tp+fp) if tp+fp else 0.0
        r = tp/(tp+fn) if tp+fn else 0.0
        f = 2*p*r/(p+r) if p+r else 0.0
        per_class[str(c)] = {"precision":p,"recall":r,"f1":f,"support":sum(a==c for a in yt)}
    accuracy = sum(a == b for a,b in zip(yt,yp))/len(yt) if yt else 0.0
    macro_f1 = float(np.mean([v["f1"] for v in per_class.values()]))
    return {"accuracy":accuracy, "macro_f1":macro_f1, "per_class":per_class}


def regression_metrics(y_true, y_pred):
    a, b = np.asarray(y_true, dtype=float), np.asarray(y_pred, dtype=float)
    mask = np.isfinite(a) & np.isfinite(b)
    a, b = a[mask], b[mask]
    if a.size == 0:
        return {"mae": float("nan"), "rmse": float("nan"), "n": 0}
    err = a-b
    return {"mae":float(np.mean(np.abs(err))),
            "rmse":float(np.sqrt(np.mean(err**2))), "n":int(a.size)}


def court_position_metrics(gt, pred):
    gt = np.asarray(gt, dtype=float)
    pred = np.asarray(pred, dtype=float)
    if gt.shape != pred.shape or gt.ndim != 2 or gt.shape[1] != 2:
        raise ValueError("Court positions must be Nx2 arrays with identical shapes.")
    d = np.linalg.norm(gt-pred, axis=1)
    return {
        "position_mae_m": float(np.mean(d)),
        "position_rmse_m": float(np.sqrt(np.mean(d**2))),
        "x_mae_m": float(np.mean(np.abs(gt[:,0]-pred[:,0]))),
        "y_mae_m": float(np.mean(np.abs(gt[:,1]-pred[:,1]))),
        "n": int(len(d))
    }


def event_prf(gt_events, pred_events, tolerance_frames=3,
              event_type=None, team_key="team"):
    """
    One-to-one temporal event matching. Event type is required to match.
    Team is matched when both events provide it.
    """
    gt = [e for e in gt_events if event_type is None or e.get("type")==event_type]
    pr = [e for e in pred_events if event_type is None or e.get("type")==event_type]
    used = set()
    tp = 0
    for p in sorted(pr, key=lambda e: int(e["frame"])):
        candidates=[]
        for i,g in enumerate(gt):
            if i in used: continue
            if team_key in p and team_key in g and p[team_key] != g[team_key]:
                continue
            d=abs(int(p["frame"])-int(g["frame"]))
            if d <= tolerance_frames:
                candidates.append((d,i))
        if candidates:
            _, i=min(candidates)
            used.add(i); tp+=1
    fp=len(pr)-tp; fn=len(gt)-tp
    precision=tp/(tp+fp) if tp+fp else 0.0
    recall=tp/(tp+fn) if tp+fn else 0.0
    f1=2*precision*recall/(precision+recall) if precision+recall else 0.0
    return {"precision":precision,"recall":recall,"f1":f1,
            "tp":tp,"fp":fp,"fn":fn,"temporal_tolerance_frames":tolerance_frames}


def _frame_detections(records):
    out={}
    for r in records:
        out.setdefault(int(r["frame"]), []).append(r)
    return out


def idf1_from_tracks(gt_records, pred_records, iou_threshold=0.5):
    """
    IDF1 implementation for single-camera MOT.
    Records: frame, track_id, bbox.
    Frame detections are matched by IoU; a global GT-ID/PRED-ID assignment
    maximizes the number of identity-consistent matched detections.
    """
    gt = _frame_detections(gt_records)
    pr = _frame_detections(pred_records)
    gt_ids=sorted({int(r["track_id"]) for r in gt_records})
    pr_ids=sorted({int(r["track_id"]) for r in pred_records})
    if not gt_ids:
        return {"IDF1":float("nan"),"IDP":float("nan"),"IDR":float("nan"),
                "IDTP":0,"IDFP":0,"IDFN":0}

    affinity=np.zeros((len(gt_ids),len(pr_ids)),dtype=np.int64)
    for f in sorted(set(gt)|set(pr)):
        g=gt.get(f,[]); p=pr.get(f,[])
        for gr in g:
            for pp in p:
                if bbox_iou(gr["bbox"],pp["bbox"]) >= iou_threshold:
                    affinity[gt_ids.index(int(gr["track_id"])),
                             pr_ids.index(int(pp["track_id"]))]+=1
    rows,cols=linear_sum_assignment(-affinity)
    idtp=int(affinity[rows,cols].sum()) if len(rows) else 0

    # Total predicted/GT detections used in IDF1 denominator.
    total_gt=sum(len(v) for v in gt.values())
    total_pr=sum(len(v) for v in pr.values())
    idfn=total_gt-idtp
    idfp=total_pr-idtp
    idp=idtp/(idtp+idfp) if idtp+idfp else 0.0
    idr=idtp/(idtp+idfn) if idtp+idfn else 0.0
    idf1=2*idp*idr/(idp+idr) if idp+idr else 0.0
    return {"IDF1":idf1,"IDP":idp,"IDR":idr,
            "IDTP":idtp,"IDFP":idfp,"IDFN":idfn}


def possession_f1(gt_labels, pred_labels, ignore_unknown=True):
    labels=(1,2) if ignore_unknown else (0,1,2)
    # Report macro F1 over labels that actually occur in GT or prediction.
    present=tuple(c for c in labels if c in set(gt_labels) or c in set(pred_labels))
    result=classification_metrics(gt_labels,pred_labels,labels=present or labels)
    result["f1"]=result["macro_f1"]
    return result


def evaluate_speed(gt_speed, pred_speed):
    return regression_metrics(gt_speed,pred_speed)


def evaluate_events(gt_events, pred_events, tolerance_frames=3):
    return {
        "pass": event_prf(gt_events,pred_events,tolerance_frames,"pass"),
        "interception": event_prf(gt_events,pred_events,tolerance_frames,"interception")
    }
