"""
Run all Basketball Intelligence System evaluation metrics.

Ground truth and prediction JSON schema is documented in evaluation/README.md.

Usage:
    python evaluation/evaluate_project.py \
        --gt data/ground_truth/ground_truth.json \
        --pred data/predictions/predictions.json \
        --report reports/metrics.json
"""
import argparse, json, math
from pathlib import Path
import numpy as np
from metrics import (
    evaluate_detection, classification_metrics, regression_metrics,
    court_position_metrics, evaluate_events, idf1_from_tracks,
    possession_f1
)

def load_json(path):
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def frames_as_dict(obj):
    return {str(k):v for k,v in obj.get("frames",{}).items()}

def flatten_tracks(frames, key="players"):
    rows=[]
    for fs, data in frames.items():
        frame=int(fs)
        for p in data.get(key,[]) or []:
            if "track_id" in p and "bbox" in p:
                rows.append({"frame":frame,"track_id":int(p["track_id"]),
                             "bbox":p["bbox"]})
    return rows

def collect_team_labels(gt_frames,pred_frames):
    yt=[]; yp=[]
    for f in sorted(set(gt_frames)&set(pred_frames),key=int):
        g={int(p["track_id"]):p for p in gt_frames[f].get("players",[]) if "track_id" in p}
        p={int(x["track_id"]):x for x in pred_frames[f].get("players",[]) if "track_id" in x}
        for tid in sorted(set(g)&set(p)):
            if "team_id" in g[tid] and "team_id" in p[tid]:
                yt.append(int(g[tid]["team_id"])); yp.append(int(p[tid]["team_id"]))
    return yt,yp

def collect_scalar_by_player_frame(gt_frames,pred_frames,key):
    gt=[]; pr=[]
    for f in sorted(set(gt_frames)&set(pred_frames),key=int):
        g={int(x["track_id"]):x for x in gt_frames[f].get("players",[]) if "track_id" in x}
        p={int(x["track_id"]):x for x in pred_frames[f].get("players",[]) if "track_id" in x}
        for tid in sorted(set(g)&set(p)):
            if key in g[tid] and key in p[tid]:
                gt.append(float(g[tid][key])); pr.append(float(p[tid][key]))
    return gt,pr

def collect_court_positions(gt_frames,pred_frames):
    gt=[]; pr=[]
    for f in sorted(set(gt_frames)&set(pred_frames),key=int):
        g={int(x["track_id"]):x for x in gt_frames[f].get("players",[]) if "track_id" in x}
        p={int(x["track_id"]):x for x in pred_frames[f].get("players",[]) if "track_id" in x}
        for tid in sorted(set(g)&set(p)):
            if "court_xy" in g[tid] and "court_xy" in p[tid]:
                gt.append(g[tid]["court_xy"]); pr.append(p[tid]["court_xy"])
    return gt,pr

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--gt",required=True)
    ap.add_argument("--pred",required=True)
    ap.add_argument("--report",default="reports/metrics.json")
    args=ap.parse_args()

    gt=load_json(args.gt); pred=load_json(args.pred)
    gf=frames_as_dict(gt); pf=frames_as_dict(pred)

    result={
      "notes": [
        "All scores require manually annotated ground truth.",
        "The target thresholds are project goals, not measured results."
      ]
    }

    result["detection_player"]=evaluate_detection(gf,pf,"players")
    result["detection_ball"]=evaluate_detection(gf,pf,"ball")

    gt_tracks=flatten_tracks(gf); pr_tracks=flatten_tracks(pf)
    result["tracking_idf1"]=idf1_from_tracks(gt_tracks,pr_tracks,0.5)

    yt,yp=collect_team_labels(gf,pf)
    result["team_classification"]=classification_metrics(yt,yp,labels=(1,2))

    gt_xy,pr_xy=collect_court_positions(gf,pf)
    if gt_xy:
        result["court_mapping"]=court_position_metrics(gt_xy,pr_xy)
    else:
        result["court_mapping"]={"error":"No court_xy pairs found."}

    gt_speed,pr_speed=collect_scalar_by_player_frame(gf,pf,"speed_kmh")
    result["speed"]=regression_metrics(gt_speed,pr_speed)

    # Possession labels are frame-level: gt/pred JSON uses possession_team.
    poss_gt=[]; poss_pr=[]
    for f in sorted(set(gf)&set(pf),key=int):
        if "possession_team" in gf[f] and "possession_team" in pf[f]:
            poss_gt.append(int(gf[f]["possession_team"]))
            poss_pr.append(int(pf[f]["possession_team"]))
    result["possession"]=possession_f1(poss_gt,poss_pr,ignore_unknown=True)

    result["events"]=evaluate_events(gt.get("events",[]) or [],
                                     pred.get("events",[]) or [],
                                     tolerance_frames=int(gt.get("event_tolerance_frames",3)))

    Path(args.report).parent.mkdir(parents=True,exist_ok=True)
    with open(args.report,"w",encoding="utf-8") as f:
        json.dump(result,f,indent=2)
    print(json.dumps(result,indent=2))
    print(f"\nSaved report: {args.report}")

if __name__=="__main__":
    main()
