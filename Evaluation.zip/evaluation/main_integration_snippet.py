# Add this near the end of main.py, after:
#   player_speed_per_frame = ...
# and after passes/interceptions have been computed.

from evaluation.prediction_exporter import save_predictions

# `tactical_player_positions` must be the result returned by
# get_tactical_player_positions(...) or calculate_player_speed_and_distance(...).
# If main.py currently only keeps distance/speed, expose tactical positions too.

save_predictions(
    output_path=BASE_DIR / "data" / "predictions" / "predictions.json",
    player_tracks=player_tracks,
    ball_tracks=ball_tracks,
    player_assignment=player_assignment,
    ball_aquisition=ball_aquisition,
    passes=passes,
    interceptions=interceptions,
    tactical_player_positions=tactical_player_positions,
    player_speed_per_frame=player_speed_per_frame,
)

print("Prediction export complete.")
print("Next step: annotate data/ground_truth/ground_truth.json")
print("Then run:")
print("python evaluation/evaluate_project.py "
      "--gt data/ground_truth/ground_truth.json "
      "--pred data/predictions/predictions.json "
      "--report reports/metrics.json")
