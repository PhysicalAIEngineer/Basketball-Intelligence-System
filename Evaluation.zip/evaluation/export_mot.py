"""
Convert project tracking JSON into MOTChallenge text files for TrackEval.

Usage:
  python evaluation/export_mot.py \
      --input data/predictions/predictions.json \
      --output data/predictions/mot_pred.txt
"""
import argparse, json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input",required=True)
    ap.add_argument("--output",required=True)
    args=ap.parse_args()
    with open(args.input,"r",encoding="utf-8") as f: data=json.load(f)
    rows=[]
    for frame_s,fd in data.get("frames",{}).items():
        frame=int(frame_s)
        for p in fd.get("players",[]) or []:
            if "track_id" not in p or "bbox" not in p: continue
            x1,y1,x2,y2=map(float,p["bbox"])
            w=max(0,x2-x1); h=max(0,y2-y1)
            conf=float(p.get("confidence",1.0))
            rows.append((frame,int(p["track_id"]),x1,y1,w,h,conf,-1,-1))
    rows.sort()
    Path(args.output).parent.mkdir(parents=True,exist_ok=True)
    with open(args.output,"w") as f:
        for r in rows:
            f.write(",".join(str(x) for x in r)+"\n")
    print(f"Wrote {len(rows)} MOT rows to {args.output}")
if __name__=="__main__": main()
