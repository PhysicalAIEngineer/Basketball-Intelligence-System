"""
Confidence-aware BallTracker replacement.

The upstream BallTracker currently saves only bbox for the selected ball.
This version also stores confidence, which is required for meaningful AP/mAP.
"""
from ultralytics import YOLO
import supervision as sv
from utils import read_stub, save_stub


class BallTracker:
    def __init__(self, model_path):
        self.model = YOLO(model_path)
        self.trackers = sv.ByteTrack()

    def detect_frames(self, frames):
        batch_size=20
        detections=[]
        for i in range(0,len(frames),batch_size):
            detections += self.model.predict(frames[i:i+batch_size], conf=0.5)
        return detections

    def get_object_tracks(self, frames, read_from_stub=False, stub_path=None):
        tracks=read_stub(read_from_stub,stub_path)
        if tracks is not None and len(tracks)==len(frames):
            return tracks

        detections=self.detect_frames(frames)
        tracks=[]

        for frame_num,detection in enumerate(detections):
            cls_names=detection.names
            cls_names_inv={v:k for k,v in cls_names.items()}
            ds=sv.Detections.from_ultralytics(detection)
            tracks.append({})

            chosen_bbox=None
            chosen_conf=0.0

            for row in ds:
                bbox=row[0].tolist()
                conf=float(row[2])
                cls_id=int(row[3])

                if cls_id == cls_names_inv["Ball"] and conf > chosen_conf:
                    chosen_bbox=bbox
                    chosen_conf=conf

            if chosen_bbox is not None:
                tracks[frame_num][1]={
                    "bbox":chosen_bbox,
                    "confidence":chosen_conf,
                    "class_id":0
                }

        save_stub(stub_path,tracks)
        return tracks
