"""
Confidence-aware PlayerTracker replacement.

This is a drop-in version of the repository's PlayerTracker with one important
evaluation addition: it preserves YOLO confidence in each tracked detection.

Use this file only if you want valid detection AP/mAP from the stored tracking
JSON. The original repository stores bbox + track_id but drops confidence.
"""
from ultralytics import YOLO
import supervision as sv
from utils import read_stub, save_stub


class PlayerTracker:
    def __init__(self, model_path):
        self.model = YOLO(model_path)
        self.tracker = sv.ByteTrack()

    def detect_frames(self, frames):
        batch_size = 20
        detections = []
        for i in range(0, len(frames), batch_size):
            detections += self.model.predict(frames[i:i+batch_size], conf=0.5)
        return detections

    def get_object_tracks(self, frames, read_from_stub=False, stub_path=None):
        tracks = read_stub(read_from_stub, stub_path)
        if tracks is not None and len(tracks) == len(frames):
            return tracks

        detections = self.detect_frames(frames)
        tracks = []

        for frame_num, detection in enumerate(detections):
            cls_names = detection.names
            cls_names_inv = {v:k for k,v in cls_names.items()}
            ds = sv.Detections.from_ultralytics(detection)

            tracks.append({})

            # Keep confidence/class aligned with detections.
            for row in ds:
                bbox = row[0].tolist()
                confidence = float(row[2])
                cls_id = int(row[3])
                track_id = int(row[4])

                if cls_id == cls_names_inv["Player"]:
                    tracks[frame_num][track_id] = {
                        "bbox": bbox,
                        "confidence": confidence,
                        "class_id": cls_id
                    }

        save_stub(stub_path, tracks)
        return tracks
